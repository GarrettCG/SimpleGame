This section will help you setup MonoGame on Platform of your choice. Please select the platform you wish to develop from:

 - Windows
 - Mac
 - [Linux](setting_up_monogame_linux.md)
 - [Building from source](setting_up_monogame_source.md)
