Links to several useful reference sites related to MonoGame.

 - [Microsoft XNA Documentation](http://msdn.microsoft.com/en-us/library/bb203940.aspx)
 - [OpenGL 4.3 Reference Card](http://www.khronos.org/files/opengl43-quick-reference-card.pdf)
 - [OpenGL ES 2.0 Reference Card](http://www.khronos.org/opengles/sdk/docs/reference_cards/OpenGL-ES-2_0-Reference-card.pdf)
 - [PlayStation Mobile SDK Docs](https://psm.playstation.net/static/general/dev/en/sdk_docs/)
 - [WebGL Reference Card](http://www.khronos.org/files/webgl/webgl-reference-card-1_0.pdf)
 - [Collada Specification](http://www.khronos.org/collada/)
 - [Valve's Guide to Porting to Linux](https://developer.nvidia.com/sites/default/files/akamai/gamedev/docs/Porting%20Source%20to%20Linux.pdf)
 
