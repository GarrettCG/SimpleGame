SPANISH
este sprite ha sido dise�ado por Dk!
Usalo donde quieras!solo te pido que me des las gracias en mi email:
imdok.exe@gmail.com

ENGLISH
this sprite was designed by Dk!
use it anywhere!,I just ask you to thanks me to my email:
imdok.exe@gmail.com